# sp2-coursework
Urooj Inam Mohammed, Student ID: 13168801

Academic Declaration: 
"I have read and understood the sections of plagiarism in College Policy on assessment offences and confirm that the work is my own, with the work of others clearly acknowledged. I give my permission to submit my report to the plagiarism testing database that the College is using and test it using plagiarism detection software, search engines or meta-searching software."