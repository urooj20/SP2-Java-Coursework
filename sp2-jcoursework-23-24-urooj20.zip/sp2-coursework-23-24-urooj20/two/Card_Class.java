// @author // Urooj Inam Mohammed // My References: I have followed W3 School, Stack Over-Flow and Git Hub as guide to help me with understanding the basics of my code. 
// The code written is my own work and my own configuring. 


// I have done the following questions 1. and 2. see below:

// 1. Begin by writing declarations for each of the sub-classes. For each sub-class, supply private instance variables.
// 2. Implement constructors for each of three sub-classes. Each constructor should call the super-class constructor to set the name and possinly the id.

public class Card_Class {
 private String Name;
 private String Card_Number;

 public Card_Class(String Name, String Card_Number) {
    this.Name = Name;
    this.Card_Number = Card_Number;
 
}
    
 // Here the implementation of getting and setting for Name and Card_Number occurs

}


public class Calling_Card extends Card_Class {
    private int pin;

    public Calling_Card(String Name, String Card_Number int pin) {
        super(Name, Card_Number);
        this.pin = pin;

// Here the implementation of getting and setting for the pin occurs

    }


}

  public class Id_Card extends Card_Class {
    private String Id_Number;

    public Id_Card(String Name, String Card_Number, String Id_Number) {
        super(Name, Card_Number);
        this.Id_Number = Id_Number;
  
        // Here the implementation of getting and setting for Id_Number occurs

    }


  }
   
  
  public class Driver_License extends Id_Card {
        private int Expiration_Year;

        public Driver_License(String Name, String Card_Number, String Id_Number, int expiration_year ) {
           super(Name, Card_Number, Id_Number); 
           this.Expiration_Year = Expiration_Year;

// Here the implementation of getting and setting for the Expiration_Year

        }

    } 

    

// 3. Replace the implementation of the format method for the three sub-classes. The methods should produce a formatted description of the card detials. The sub-class methods should call the super-class format method to get the formatted name of the cardholder.

public class Card_Class {
    private String Name;
    private String Card_Number;

    public Card_Class(String Name, String Card_Number) {
        this.Name = Name;
        this.Card_Number = Card_Number;

    }

}

public String format() {
    return "Card Holder: " + Name + "\nCard Number: " + Card_Number; 
}

// Here the implementation of getting and setting for the Name and Card_Number occurs


public class Calling_Card extends Card_Class {
    private int pin;

    public Calling_Card(String Name, String Card_Number, int pin) {
        super(Name, Card_Number);
        this.pin = pin;

    }

}


@Override
public String format() {
    String Card_Detials = super.format();
    return Card_Detials + "\nPIN: " + pin;
}

// Here the implementation of getting and setting for pin occurs


public class Id_Card extends Card_Class {
    private String Id_Number;

    public Id_Card(String Name, String Card_Number, String Id_Number) {
        super(Name, Card_Number);
        this.Id_Number = Id_Number;

    }

}


@Override
public String format() {
    String Card_Detials = super.format();
    return Card_Detials + "\nID Number: " + Id_Number; 
}

// Here the implementation of getting and setting for Id_Number occurs.


public class Driver_License extends Id_Card {
    private int Expiration_Year;

    public Driver_License(String Name, String Card_Number, String Id_Number, int Expiration_Year) {
        super(Name, Card_Number, Id_Number);
        this.Expiration_Year = Expiration_Year;

    }

}


@Override
public String format() {
    String Card_Detials = super.format();
    return Card_Detials + "\nExpiration Year: " + Expiration_Year;

}

// Here the implementation of getting and setting for Expiration_Year occurs

// As a result every sub-class will over-ride the format procedure to fix precise data relevant to that kind of card by utilising rhe super.format to get the formatted name of the Card_Holder via the super-class Card_Class.



// 4. Devise another class, Wallet, which contains slots for two cards, card1 and card2, a method void addCard(Card) and a method String formatCrds(). The addCard method should check whether card is null. If so, it sets card 1 to the new card. If not, it checks card2. If both cards are set already, the method has no effect. formatCards should invoke the format method on each non-null card and produce a string with the format [card1]card2]

public class Wallet {
    private Card_Class Card_1;
    private Card_Class Card_2;

    public void Add_Card(Card_Class New_Card) {
        if (Card_1 == null) {
            Card_1 = New_Card; 
        } else if (Card_2 == null) {
            Card_2 = New_Card;
        }

    }


    public String Format_Cards() {
        String Formatted_Card_1 = (Card_1 != null) ? Card_1.format() : "";
        String Formatted_Card_2 = (Card_2 != null) ? Card_2.format() : "";

        return "[" + Formatted_Card_1 + "|" + Formatted_Card_2 + "]";

    }

}



// 5. Write a tester class WalletTester that adds two objects of different sub-classes of Card to a Wallet object. Test the results of the formatCards methods.

public class Wallet_Tester {
    public static void main(String[] args) {
        
        // Here I'm making a wallet object
        Wallet wallet = new Wallet();

    }

}

// Now I'm making the cards unique
Calling_Card callingCard = new Calling_Card("Urooj", "1999", 2005);
Id_Card idCard = new Id_Card("Ricky", "7777" "ID222");
Driver_License driver_License = new Driver_License("Humf", "6969", "BW888" 1890);

// Inserting cards to the wallett
wallet.addCard(callingCard);
wallet.addCard(idCard);

// Testing the format cards procedure
String formattedCards = wallet.formatCards();
System.out.println("Formatted Cards: " + formattedCards); 



// 6. I have implemented the Gregorian calendar process here

import java.util.Calendar;
import java.util.GregorianCalendar;

import Calling_Card.Id_Card;

public class Driver_License extends Id_Card {
    private int expiration_year;

    public Driver_License(String name, String card_number, string id_number, int expiration_year) {
        super(name, card_number id_number);
        this.expiration_year = expiration_year;

    }

}

public boolean isExpired() {
    GregorianCalendar calendar = new GregorianCalendar();
    int currentYear = calender.get(Calendar.YEAR);
    return expiration_year < currentYear;

    // Implementation for getting and setting for expiration_year occurs here
    // Gregorian calender method implemented 


